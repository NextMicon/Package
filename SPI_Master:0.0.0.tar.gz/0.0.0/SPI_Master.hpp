#pragma once
#include "cpu.hpp"
#include <stdint.h>

class Wire {
};
